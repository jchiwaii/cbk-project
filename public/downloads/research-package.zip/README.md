# Kenya economic research

Research snapshot: 13 November 2026 (Africa/Nairobi).

Read [the economic analysis](research/kenya-economy-analysis.md) and [source inventory](research/source-catalog.md). Original downloads are under `data/raw/`; cleaned data, calculations, source-quality findings and dashboard inputs are under `data/processed/`.

The Next.js dashboard and hosting are deferred until the user supplies the design. No site has been registered or published.

## Reproduce

1. Archive the current data directory before a refresh: source downloads may be revised in place.
2. Run `python3 scripts/collect.py` with network access. It downloads nine statistical pages and their linked CSV/XLSX files with bounded concurrency. The separate forex entry-page snapshot was downloaded during discovery.
3. Run `scripts/analyze.py` with a Python environment containing pandas and openpyxl. On this workstation the supplied runtime is `/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`.
4. Run `scripts/validate.py` and `scripts/write_report.py` in that runtime.
5. Run `.venv/bin/python scripts/charts.py` for the static charts (matplotlib required).

The narrative is an analyst-authored snapshot. Refreshing numeric outputs does not automatically update every sentence or current-affairs item; review and date the report before reissuing it. The collection manifest records hashes and source URLs. The scripts do not write back to CBK or modify original spreadsheet contents.

## Interpretation contracts

- Fiscal flow observations are cumulative July-to-date. June is the fiscal-year outturn. Monthly increments require consecutive observations in the same fiscal year.
- Debt and monetary observations are stocks. Do not sum them across months.
- Trade and remittance data are flows. Compare identical month coverage and keep currency units explicit.
- Annual GDP, quarterly GDP, reported growth, and level-derived growth are separate measures. Some source vintages do not reconcile.
- Country, region and economic-bloc remittance rows overlap. Only the designated regional totals sum to the grand total.
- Standard and expanded monetary surveys have different institutional coverage.
- GDP sector contributions are provisional; the source level/rate inconsistency is not resolved by this package.
- Current affairs are an attributed selection, not a representative sentiment estimate.

## Planned application

Use Next.js after design is supplied. Serve a versioned data snapshot, expose observation dates and sources, and keep forecasts distinct from actuals. `dashboard-data.json` contains analysis summaries, coverage and quality issues; the per-dataset CSV files supply historical series. Publication and a data-refresh schedule have not yet been implemented.
