"""Download CBK statistics with source provenance; preserve original bytes."""
from pathlib import Path
from urllib.parse import urljoin, quote, unquote, urlsplit
import re, html, json, hashlib, subprocess, datetime
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).resolve().parents[1]
BASE = 'https://www.centralbank.go.ke/'
PAGES = ['statistics/national-accounts-statistics/', 'inflation-rates/',
 'statistics/government-finance-statistics/', 'foreign-trade-summary/',
 'diaspora-remittances/', 'statistics/balance-of-payment-statistics/',
 'statistics/monetary-finance-statistics/', 'statistics/exchange-rates/',
 'commercial-banks-weighted-average-rates/']

def links(text):
    return [(html.unescape(u), html.unescape(re.sub('<[^>]+>', '', t)).strip())
      for u,t in re.findall(r'<a[^>]+href=[\"\']([^\"\']+)[\"\'][^>]*>(.*?)</a>',text,re.S)]

def download(url, path):
    path.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(['curl','-sS','-L','--fail','--retry','2','--max-time','90',
      quote(url,safe=':/?=&%+#'),'-o',str(path)], check=True)
    return path.read_bytes()

def main():
    manifest=[]
    def page(p):
        url=urljoin(BASE,p); path=ROOT/'data/pages'/(p.strip('/').replace('/','_')+'.html')
        raw=download(url,path)
        return url,links(raw.decode('utf-8',errors='replace'))
    pages=list(ThreadPoolExecutor(max_workers=4).map(page,PAGES))
    found={}
    for page_url, anchors in pages:
        for href,title in anchors:
            if re.search(r'\.(xlsx?|csv)(?:\?|$)',href,re.I):
                url=urljoin(page_url,href)
                found.setdefault(url,{'url':url,'title':title,'page':page_url})
    def file(entry):
        name=unquote(urlsplit(entry['url']).path.rsplit('/',1)[-1])
        name=re.sub(r'[^A-Za-z0-9._-]+','_',name)
        path=ROOT/'data/raw'/name
        try:
            raw=download(entry['url'],path)
            entry.update(path=str(path.relative_to(ROOT)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),status='downloaded')
        except Exception as e: entry.update(status='failed',error=str(e))
        entry['retrieved_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        return entry
    manifest=list(ThreadPoolExecutor(max_workers=4).map(file,found.values()))
    (ROOT/'data/manifest.json').write_text(json.dumps(manifest,indent=2))
    for x in manifest: print(x['status'],x['title'],x.get('path',x['url']))
    print('TOTAL',len(manifest))

if __name__=='__main__':main()
