"""Independent checks on provenance, period matching and headline accounting."""
from pathlib import Path
import csv,json,hashlib,math,collections
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'data/processed'
A=json.loads((P/'analysis.json').read_text());checks=[]
def check(name,ok,detail=''):
    checks.append({'check':name,'passed':bool(ok),'detail':detail})
def close(a,b,tol=0.05):return abs(a-b)<=tol
def read(name):return list(csv.DictReader((P/(name+'.csv')).open()))
manifest=json.loads((ROOT/'data/manifest.json').read_text())
check('Every original file matches its recorded SHA-256',all(hashlib.sha256((ROOT/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest))
obs=read('observations');keys=[(x['dataset'],x['period'],x['metric']) for x in obs]
check('Canonical series keys are unique',len(keys)==len(set(keys)))
check('Every observation is finite and has source provenance',all(math.isfinite(float(x['value'])) and x['source_url'] and x['source_locator'] for x in obs))
trade=read('trade');sel=[x for x in trade if '2026-01'<=x['period']<='2026-08']
check('Trade comparison uses eight months',len(sel)==8)
imports=sum(float(x['Imports CIF']) for x in sel);exports=sum(float(x['Exports FOB']) for x in sel)
check('YTD deficit reconciles independently',close(exports-imports,A['trade_ytd']['Trade balance']['current']))
check('Trade balance reconciles in every month',all(close(float(x['Exports FOB'])-float(x['Imports CIF']),float(x['Trade balance'])) for x in trade))
f=next(x for x in read('fiscal') if x['period']=='2026-06')
def fv(k):return float(f[k])
check('Fiscal full-year deficit uses June cumulative amounts',close(fv('Total expenditure')-fv('Total revenue')-fv('Total grants'),A['fiscal_year_ends']['2026-06']['Deficit including grants']))
check('Interest burden recomputes independently',close((fv('Domestic interest')+fv('Foreign interest'))/fv('Total revenue')*100,A['fiscal_year_ends']['2026-06']['Interest to revenue percent'],1e-9))
r=read('remittances_sources');sel=[x for x in r if '2026-01'<=x['period']<='2026-10']
check('Remittance comparison uses ten months',len(sel)==10)
check('Remittance YTD total reconciles independently',close(sum(float(x['GRAND TOTAL']) for x in sel),A['remittances_sources_ytd']['GRAND TOTAL']['current']))
check('Remittance regional totals reconcile',all(close(sum(float(v) for k,v in x.items() if k.startswith('Total ')),float(x['GRAND TOTAL'])) for x in r))
b=A['bop_latest'];ca=b['Goods: exports f.o.b.']-b['Goods: imports f.o.b.']+b['Services: credit']-b['Services: debit']+b['Primary income: credit']-b['Primary income: debit']+b['Secondary income, n. i. e.: credit']-b['Secondary income: debit']
check('2025 current account reconciles',close(ca,b['A. Current Account, n.i.e.'],2))
issues=json.loads((P/'quality_issues.json').read_text())
check('GDP disagreement is explicitly flagged',any(x['type']=='gdp_growth_vintage_mismatch' and x['period']=='2026-Q1' for x in issues))
feb=next(x for x in read('bank_rates') if x['period']=='2026-02')
check('Conflicting February deposit/savings observations are excluded',feb['Deposit']=='' and feb['Savings']=='')
check('Source files contain no dates beyond research cutoff',all(x['period']<='2026-11-13' for x in obs if '-Q' not in x['period']))
result={'as_of':'2026-11-13','checks':checks,'passed':sum(x['passed'] for x in checks),'total':len(checks),'quality_issue_counts':dict(collections.Counter(x['type'] for x in issues))}
(P/'validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
if not all(x['passed'] for x in checks):raise SystemExit(1)
