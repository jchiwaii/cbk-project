"""Normalize downloaded CBK files and compute reproducible, period-matched analysis.
Run with the bundled Python runtime (pandas + openpyxl). Originals are never edited.
"""
from pathlib import Path
import csv, json, re, html, calendar, hashlib
import pandas as pd
import openpyxl

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data/processed'
OUT.mkdir(exist_ok=True)
manifest=json.loads((ROOT/'data/manifest.json').read_text())
records=[]; issues=[]; datasets={}
def num(v):
    if v is None:return None
    s=str(v).strip().replace(',','')
    try:return float(s)
    except ValueError:return None
def source(pattern):
    return next(x for x in manifest if pattern in x.get('path',''))
def rows(pattern):
    s=source(pattern)
    return s,list(csv.reader((ROOT/s['path']).open(encoding='utf-8-sig',errors='replace')))
def add(dataset,period,metric,value,unit,s,locator,status='reported'):
    value=num(value)
    if dataset=='principal_exports':
        unit='tonnes' if metric.endswith('volume') else 'KES per tonne' if metric.endswith('unit price') else 'KES million'
    if dataset=='fiscal':unit='KES million; fiscal-year cumulative'
    if dataset=='fx_average':unit=('foreign currency units per KES' if 'inverse' in metric else 'KES per 100 JPY' if metric=='JPY100' else 'KES per foreign currency unit')
    if value is not None:
        records.append(dict(dataset=dataset,period=period,metric=metric,value=value,unit=unit,
            source_url=s['url'],source_file=s.get('path',''),source_locator=locator,status=status))
def monthly(dataset,pattern,headers,unit='KES million'):
    s,rr=rows(pattern)
    for i,r in enumerate(rr):
        if len(r)>2 and re.fullmatch(r'\d{4}',r[0].strip()) and num(r[1]) is not None and 1<=num(r[1])<=12:
            p=f'{int(r[0]):04d}-{int(r[1]):02d}'
            for j,h in enumerate(headers,2):
                if j<len(r):add(dataset,p,h,r[j],unit,s,f'row {i+1}, column {j+1}')

s,rr=rows('Annual_GDP')
for i,r in enumerate(rr[1:],2):
    if re.fullmatch(r'\d{4}',r[0]):
        for j,h,u in [(2,'Nominal GDP','KES million'),(3,'Reported real GDP growth','percent'),(4,'Real GDP','KES million; source vintage base')]:
            add('annual_gdp',r[0],h,r[j],u,s,f'row {i}, column {j+1}')

s,rr=rows('Quarterly_GDP')
year=None
for c in range(2,len(rr[3])):
    if num(rr[2][c]):year=int(num(rr[2][c]))
    if not year:continue
    period=f'{year}-{rr[3][c]}'
    for r in range(4,25):add('quarterly_gdp',period,rr[r][1].strip(),rr[r][c],'KES million; constant 2016 prices',s,f'row {r+1}, column {c+1}')
    for r in range(33,53):add('quarterly_gdp_growth',period,rr[r][1].strip(),rr[r][c],'percent',s,f'row {r+1}, column {c+1}')

monthly('trade','Foreign_Trade_Summary',['Commercial imports','Government imports','Imports CIF','Domestic exports FOB','Re-exports','Exports FOB','Trade balance'])
monthly('public_debt','Public_Debt',['Domestic debt','External debt','Total debt'])
monthly('fiscal','Revenue_and_Expenditure',['Import duty','Excise duty','Income tax','VAT','Other tax','Tax revenue','Non-tax revenue','Total revenue','Programme grants','Project grants','Total grants','Domestic interest','Foreign interest','Wages and salaries','Pensions','Other recurrent','Total recurrent','County transfers','Development expenditure','Total expenditure'])
monthly('fx_average','Monthly_Exchange_rate_period_average',['USD','GBP','EUR','ZAR','UGX inverse','TZS inverse','RWF inverse','BIF inverse','AED','DEM','CAD','FRF','CHF','NLG','ITL','BEF','JPY100','SEK','NOK','DKK','ATS','FIM','ESP','INR','HKD','SGD','SAR','CNY','AUD'],'KES per foreign unit except labelled inverse rates')
for dataset,pat,hi in [('imports_commodity','Imports_by_Commodities',2),('exports_commodity','Selected_Domestic_Exports',3),('exports_africa','Exports_to_Selected_Africa',2),('exports_world','Exports_to_Selected_Rest',2),('imports_africa','Imports_from_Selected_African',4),('imports_world','Imports_from_Selected_Rest',2)]:
    s,rr=rows(pat);monthly(dataset,pat,[x.strip() for x in rr[hi][2:]])
monthly('principal_exports','Principal_Exports',['Coffee volume','Coffee value','Coffee unit price','Tea volume','Tea value','Tea unit price','Horticulture volume','Horticulture value','Horticulture unit price'],'mixed: volume tonnes; value KES million; unit price KES/tonne')

for dataset,name,headers in [('inflation','inflation-rates',['Annual average inflation','12-month inflation']),('remittances_history','diaspora-remittances',['North America','Europe','Rest of world','Total remittances']),('bank_rates','commercial-banks-weighted-average-rates',['Deposit','Savings','Lending','Overdraft'])]:
    path=ROOT/'data/pages'/(name+'.html');h=path.read_text()
    s={'url':'https://www.centralbank.go.ke/'+name+'/','path':str(path.relative_to(ROOT))}
    for i,row in enumerate(re.findall(r'<tr\b[^>]*>(.*?)</tr>',h,re.S)):
        cells=[html.unescape(re.sub('<[^>]+>','',v)).strip() for v in re.findall(r'<td\b[^>]*>(.*?)</td>',row,re.S)]
        if not cells or not re.fullmatch(r'\d{4}',cells[0]):continue
        m=num(cells[1])
        if m is None:
            m=next((n for n in range(1,13) if cells[1].lower().startswith(calendar.month_abbr[n].lower())),None)
        if not m:continue
        for j,metric in enumerate(headers,2):
            add(dataset,f'{int(cells[0]):04d}-{int(m):02d}',metric,cells[j],'USD thousand' if dataset=='remittances_history' else 'percent',s,f'HTML data row {i+1}, column {j+1}')

s=source('October2026.xlsx');w=openpyxl.load_workbook(ROOT/s['path'],data_only=True,read_only=True);rr=list(w.active.values);year=None
region=''
for c in range(2,95):
    if num(rr[1][c]):year=int(num(rr[1][c]))
    mon=next((n for n in range(1,13) if str(rr[2][c]).lower().startswith(calendar.month_abbr[n].lower())),None)
    if not mon or not year:continue
    for r in range(3,60):
        label=str(rr[r][1] or '').strip()
        if r in [3,9,22,34,46,51,56]:region=label;continue
        if label and num(rr[r][c]) is not None:
            metric=label if label.startswith('Total') or label=='GRAND TOTAL' else region+' / '+label
            add('remittances_sources',f'{year}-{mon:02d}',metric,rr[r][c],'USD thousand',s,f'Sheet1!{openpyxl.utils.get_column_letter(c+1)}{r+1}')

s,rr=rows('Balance_of_Payments')
context=''
for r in range(3,len(rr)):
    if rr[r][0].strip():
        label=rr[r][0].strip()
        if label.startswith(('Portfolio investment:','Other investment:')):context=label
        elif r in [26,48]:context=''
        metric=(context+' / '+label) if r in [21,22,24,25,*range(30,38),*range(39,48)] else label
        for c in range(1,8):
            if c<len(rr[r]):add('bop',rr[2][c],metric,rr[r][c],'KES million',s,f'row {r+1}, column {c+1}')

for dataset,pattern,start,yearrows,monthrow in [('money_standard','Depository_Corporation_Survey_-',3,[1,2],3),('money_expanded','Depository_Corporation_Survey_Expanded',2,[0],2)]:
    s,rr=rows(pattern);year=None
    for c in range(start,len(rr[monthrow])):
        for yr in yearrows:
            v=num(rr[yr][c]) if c<len(rr[yr]) else None
            if v and 1900<=v<=2026:year=int(v)
        mon=next((n for n in range(1,13) if rr[monthrow][c].strip().lower().startswith(calendar.month_abbr[n].lower())),None)
        if not mon or not year:continue
        section=''; growth=False
        for r in range(monthrow+1,len(rr)):
            row=rr[r]
            if len(row)<3:continue
            label=row[1].strip()
            if not label:continue
            if label=='ANNUAL GROWTH RATES':growth=True;section='Annual growth';continue
            if label in ['Central Bank of Kenya','Other Depository Corporation Survey','Depository Corporation Survey'] or label.startswith(('i)','ii)')):section=label;continue
            if c<len(row) and 'Check' not in label:add(dataset,f'{year}-{mon:02d}',section+' / '+label,row[c],'percent' if growth else 'KES million',s,f'row {r+1}, column {c+1}')

for pat in ['681695542','502403123']:
    s,rr=rows(pat)
    for i,row in enumerate(rr[3:],3):
        d=pd.NaT
        for fmt in ['%b-%y','%y-%b']:
            try:d=pd.to_datetime(row[0].strip(),format=fmt);break
            except (ValueError,TypeError):pass
        if pd.isna(d):continue
        for c,label in enumerate(rr[2][1:],1):
            if c<len(row):add('debt_instruments_'+pat,d.strftime('%Y-%m'),label.strip(),row[c],'KES million',s,f'row {i+1}, column {c+1}')

df=pd.DataFrame(records)
keys=['dataset','period','metric']
dups=df[df.duplicated(keys,keep=False)]
if len(dups):
    dups.to_csv(OUT/'duplicate_observations.csv',index=False)
    for key,g in dups.groupby(keys):
        issues.append({'type':'duplicate','key':list(key),'values':g.value.tolist(),'action':'Identical values deduplicated; conflicting values excluded from canonical series.'})
    conflicts=dups.groupby(keys).value.nunique();confkeys=set(conflicts[conflicts>1].index)
    df=df[[tuple(x) not in confkeys for x in df[keys].itertuples(index=False,name=None)]].drop_duplicates(keys)
df=df.sort_values(keys)
df.to_csv(OUT/'observations.csv',index=False)
def table(ds):
    d=df[df.dataset==ds].pivot(index='period',columns='metric',values='value').sort_index()
    datasets[ds]=d
    d.to_csv(OUT/(ds+'.csv'))
    return d
for ds in df.dataset.unique():table(ds)

def yoy(d):return (d/d.shift(12)-1)*100
def matched(ds,year,months):
    d=datasets[ds];sub=d[d.index.isin([f'{year}-{m:02d}' for m in months])]
    if len(sub)!=len(months):raise ValueError(f'Incomplete period: {ds} {year}')
    return sub.sum(min_count=len(months))
def compare(ds,year,months):
    a=matched(ds,year,months);b=matched(ds,year-1,months)
    return pd.DataFrame({'current':a,'prior':b,'change':a-b,'growth_percent':(a/b-1)*100})
results={}
for ds in ['trade','imports_commodity','exports_commodity','exports_africa','exports_world','imports_world']:
    v=compare(ds,2026,range(1,9));v.to_csv(OUT/(ds+'_ytd_comparison.csv'));results[ds+'_ytd']=v.to_dict('index')
v=compare('imports_africa',2026,range(1,8));v.to_csv(OUT/'imports_africa_jan_jul_comparison.csv');results['imports_africa_jan_jul']=v.to_dict('index')
pe=datasets['principal_exports']
pv={}
for crop in ['Coffee','Tea','Horticulture']:
    a=matched('principal_exports',2026,range(1,9));b=matched('principal_exports',2025,range(1,9))
    av=a[crop+' value'];bv=b[crop+' value'];aq=a[crop+' volume'];bq=b[crop+' volume']
    pv[crop]={'value_KES_million':av,'value_growth_percent':(av/bv-1)*100,'volume_tonnes':aq,'volume_growth_percent':(aq/bq-1)*100,'weighted_unit_price_KES_tonne':av*1e6/aq,'unit_price_growth_percent':((av/aq)/(bv/bq)-1)*100}
results['principal_exports_ytd']=pv
for ds in ['remittances_sources']:
    v=compare(ds,2026,range(1,11));v.to_csv(OUT/(ds+'_ytd_comparison.csv'));results[ds+'_ytd']=v.to_dict('index')

g=datasets['quarterly_gdp'];prev=g.loc[['2025-Q1','2025-Q2']].sum();cur=g.loc[['2026-Q1','2026-Q2']].sum()
sector=pd.DataFrame({'h1_2026':cur,'h1_2025':prev,'growth_percent':(cur/prev-1)*100,'contribution_pp':(cur-prev)/prev['GDP at market prices']*100,'share_real_gdp_percent':cur/cur['GDP at market prices']*100})
sector.to_csv(OUT/'gdp_sector_contributions.csv');results['gdp_h1']=sector.to_dict('index')
reported=datasets['quarterly_gdp_growth']['GDP at market prices']
implied=(g['GDP at market prices']/g['GDP at market prices'].shift(4)-1)*100
for p in reported.index:
    if p in implied.index and abs(implied.loc[p]-reported.loc[p])>.11:
        issues.append({'type':'gdp_growth_vintage_mismatch','period':p,'reported_percent':reported.loc[p],'level_implied_percent':implied.loc[p],'action':'Preserve both; sector contributions based on levels are provisional.'})
results['gdp_reported_latest']=reported.tail(6).to_dict()
for p,row in g.iterrows():
    err=row.loc[['Agriculture','Mining & Quarrying','Manufacturing','Electricity & water supply','Construction','Wholesale & Retail Trade','Accommodation & restaurant','Transport & Storage','Information & Communication','Financial & Insurance','Public administration','Professional, Administration & Support Services','Real estate','Education','Health','Other services','FISIM','Taxes on products']].sum()-row['GDP at market prices']
    if abs(err)>10:issues.append({'type':'gdp_reconciliation','period':p,'error_KES_million':err})

f=datasets['fiscal'];june=f[f.index.str.endswith('-06')].copy()
for p,row in f.iterrows():
    components=row[['Programme grants','Project grants']]
    if components.notna().all() and abs(components.sum()-row['Total grants'])>1:
        issues.append({'type':'fiscal_grants_reconciliation','period':p,'difference_KES_million':components.sum()-row['Total grants'],'action':'Use reported total grants consistently for the baseline; show sensitivity to component sum.'})
june['Deficit including grants']=june['Total expenditure']-june['Total revenue']-june['Total grants']
june['Interest']=june['Domestic interest']+june['Foreign interest']
june['Interest to revenue percent']=june.Interest/june['Total revenue']*100
june['Primary deficit including grants']=june['Deficit including grants']-june.Interest
june['Development share percent']=june['Development expenditure']/june['Total expenditure']*100
june.to_csv(OUT/'fiscal_year_ends.csv');results['fiscal_year_ends']=june.tail(5).to_dict('index')
# Fiscal levels are cumulative July-to-date. Only difference consecutive calendar months in the same fiscal year.
flows=[]
for p,row in f.iterrows():
    period=pd.Period(p,freq='M');prior=str(period-1)
    if period.month==7:v=row
    elif prior in f.index:v=row-f.loc[prior]
    else:continue
    flows.append({'period':p,**v.to_dict()})
pd.DataFrame(flows).to_csv(OUT/'fiscal_monthly_derived.csv',index=False)

t=datasets['trade']
for p,row in t.iterrows():
    err=row['Exports FOB']-row['Imports CIF']-row['Trade balance']
    if abs(err)>.05:issues.append({'type':'trade_balance_reconciliation','period':p,'error_KES_million':err})
for ds,metric in [('imports_world','TOTAL'),('imports_commodity','TOTAL')]:
    joined=datasets[ds][[metric]].join(t[['Imports CIF']],how='inner')
    for p,row in joined.iterrows():
        err=row[metric]-row['Imports CIF']
        if abs(err)>1:issues.append({'type':'trade_cross_table_difference','dataset':ds,'period':p,'error_KES_million':err,'action':'Use trade summary for headline totals; partner growth retains its own source vintage.'})
debt=datasets['public_debt'];results['debt_latest']={'period':debt.index[-1],**debt.iloc[-1].to_dict(),'domestic_share_percent':debt.iloc[-1]['Domestic debt']/debt.iloc[-1]['Total debt']*100}
for p,row in debt.iterrows():
    err=row['Domestic debt']+row['External debt']-row['Total debt']
    if abs(err)>.05:issues.append({'type':'debt_reconciliation','period':p,'error_KES_million':err})
r=datasets['remittances_sources'];regions=[c for c in r.columns if c.startswith('Total ')]
for p,row in r.iterrows():
    err=row[regions].sum()-row['GRAND TOTAL']
    if abs(err)>.01:issues.append({'type':'remittance_reconciliation','period':p,'error_USD_thousand':err})
# Compare workbook totals with overlapping HTML history; do not silently splice inconsistent vintages.
rh=datasets['remittances_history']
overlap=r[['GRAND TOTAL']].join(rh[['Total remittances']],how='inner')
overlap['difference_USD_thousand']=overlap['GRAND TOTAL']-overlap['Total remittances']
overlap.to_csv(OUT/'remittance_source_reconciliation.csv')
for p,row in overlap.iterrows():
    if abs(row['difference_USD_thousand'])>1:issues.append({'type':'remittance_vintage_difference','period':p,'difference_USD_thousand':row['difference_USD_thousand']})

fx=datasets['fx_average']['USD'];inf=datasets['inflation']['12-month inflation']
results['fx']={'latest_period':fx.index[-1],'latest':fx.iloc[-1],'peak_since_2020':fx[fx.index>='2020'].max(),'peak_period':fx[fx.index>='2020'].idxmax(),'change_from_peak_percent':(fx.iloc[-1]/fx[fx.index>='2020'].max()-1)*100,'yoy_percent':(fx.iloc[-1]/fx.loc['2025-10']-1)*100}
results['inflation']={'latest_period':inf.index[-1],'latest':inf.iloc[-1],'year_ago':inf.loc['2025-10'],'january_2026':inf.loc['2026-01'],'target_ceiling_gap_pp':7.5-inf.iloc[-1],'months_above_7_5_since_2020':int((inf[inf.index>='2020']>7.5).sum())}
results['remittances_latest']={'period':r.index[-1],'total_USD_thousand':r.iloc[-1]['GRAND TOTAL'],'yoy_percent':(r.iloc[-1]['GRAND TOTAL']/r.loc['2025-10','GRAND TOTAL']-1)*100,'us_share_percent':r.iloc[-1]['America / U.S.A']/r.iloc[-1]['GRAND TOTAL']*100}
annual=datasets['annual_gdp'];results['annual_gdp']=annual.tail(12).to_dict('index')
# Indicative KES value of remittances, using monthly average USD rate. Not actual conversion receipts.
kes=r['GRAND TOTAL']*fx.reindex(r.index)/1000
results['remittances_2025']={'USD_billion':r.loc['2025-01':'2025-12','GRAND TOTAL'].sum()/1e6,'indicative_KES_million':kes.loc['2025-01':'2025-12'].sum(),'indicative_GDP_share_percent':kes.loc['2025-01':'2025-12'].sum()/annual.loc['2025','Nominal GDP']*100}
bop=datasets['bop'];results['bop_latest']=bop.iloc[-1].to_dict()
results['bop_current_account_GDP_percent']=(bop['A. Current Account, n.i.e.']/annual['Nominal GDP'].reindex(bop.index)*100).to_dict()
results['bank_rates_latest']={'period':datasets['bank_rates'].index[-1],**datasets['bank_rates'].iloc[-1].to_dict()}
results['structural']={'debt_revenue':{p:{'debt_KES_million':debt.loc[p,'Total debt'],'revenue_KES_million':june.loc[p,'Total revenue'],'debt_revenue_multiple':debt.loc[p,'Total debt']/june.loc[p,'Total revenue'],'interest_revenue_percent':june.loc[p,'Interest to revenue percent']} for p in ['2015-06','2020-06','2025-06','2026-06']},'debt_CAGR_2015_2025_percent':((debt.loc['2025-06','Total debt']/debt.loc['2015-06','Total debt'])**0.1-1)*100,'revenue_CAGR_2015_2025_percent':((june.loc['2025-06','Total revenue']/june.loc['2015-06','Total revenue'])**0.1-1)*100}
remannual=rh['Total remittances'].groupby(rh.index.str[:4]).sum()
results['structural']['remittance_CAGR_2015_2025_percent']=((remannual.loc['2025']/remannual.loc['2015'])**0.1-1)*100
for ds in ['money_standard','money_expanded']:
    m=datasets[ds];p=m.index[-1];yp=f'{int(p[:4])-1}{p[4:]}'
    selected=[c for c in m.columns if c.startswith('Depository Corporation Survey /')]
    results[ds]={'period':p,'metrics':{c:{'value':m.loc[p,c],'yoy_percent':(m.loc[p,c]/m.loc[yp,c]-1)*100} for c in selected}}
    if ds=='money_expanded':
        for label in ['Money and Quasi-money (M2)',"M2 plus Residents' Foreign Curr. Deposits (M3)"]:
            calc=results[ds]['metrics']['Depository Corporation Survey / '+label]['yoy_percent'];pub=m.loc[p,'Annual growth / '+label]
            if abs(calc-pub)>.05:issues.append({'type':'money_growth_vintage_mismatch','period':p,'metric':label,'reported_percent':pub,'level_implied_percent':calc})
di=datasets['debt_instruments_681695542'];results['domestic_instruments_latest']={'period':di.index[-1],**di.iloc[-1].to_dict()}
old=datasets['debt_instruments_502403123'];common=old.index.intersection(di.index)
for p in common:
    diff=old.loc[p,'Total Domestic Debt***']-di.loc[p,'Total Domestic Debt***']
    if abs(diff)>1:issues.append({'type':'domestic_debt_vintage_difference','period':p,'difference_KES_million':diff,'action':'Use newer 681695542 vintage; preserve both originals.'})

coverage=[]
for ds,d in df.groupby('dataset'):
    coverage.append({'dataset':ds,'first_period':d.period.min(),'last_period':d.period.max(),'observations':len(d),'metrics':d.metric.nunique(),'periods':d.period.nunique()})
pd.DataFrame(coverage).to_csv(OUT/'coverage.csv',index=False)
issues.extend([
 {'type':'methodology','detail':'Annual real GDP levels span rebasing vintages; do not calculate a long-run real-level CAGR without linking consistent bases. Use published growth rates.'},
 {'type':'methodology','detail':'Revenue and expenditure are fiscal-year cumulative; June is the full fiscal year. Do not sum cumulative monthly values. Calendar-year GDP is not a fiscal-year GDP denominator.'},
 {'type':'methodology','detail':'Trade CIF imports and FOB exports differ from BPM6 goods measures. Oil re-export revisions limit interpretation of export growth as domestic production.'},
 {'type':'methodology','detail':'Expanded monetary survey includes microfinance and SACCOs. Keep separate from standard survey; FX valuation affects foreign-currency credit.'},
 {'type':'source_limitation','detail':'End-period FX download ends at an incomplete August 2011 row; retained raw but excluded from normalized analysis.'},
 {'type':'source_limitation','detail':'Annual GDP file does not explicitly state units/base in its header; KES million inferred from CBK quarterly/BOP context. Confirm metadata before publication.'}
])
(OUT/'quality_issues.json').write_text(json.dumps(issues,indent=2))
(OUT/'analysis.json').write_text(json.dumps(results,indent=2,allow_nan=False))
(OUT/'dashboard-data.json').write_text(json.dumps({'as_of':'2026-11-13','coverage':coverage,'analysis':results,'quality_issues':issues,'publication_note':'GDP level-derived contributions are provisional. See source-vintage warnings.','current_affairs':json.loads((ROOT/'research/current-affairs.json').read_text())},allow_nan=False))
print(json.dumps({'observations':len(df),'datasets':len(coverage),'issues':len(issues),'coverage':coverage},indent=2))
