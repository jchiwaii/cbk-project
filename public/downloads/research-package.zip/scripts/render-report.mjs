import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const require=createRequire('/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/marked/package.json');
const {marked}=await import(require.resolve('marked'));
const md=await fs.readFile(path.join(root,'research/kenya-economy-analysis.md'),'utf8');
let html=marked.parse(md);
for (const name of ['economic-overview.png','sector-contributions.png']) {
  const bytes=await fs.readFile(path.join(root,'research/charts',name));
  html=html.replaceAll(`src="charts/${name}"`,`src="data:image/png;base64,${bytes.toString('base64')}"`);
}
await fs.writeFile(path.join(root,'research/kenya-economy-analysis.html'),`<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Kenya economy — research, 13 November 2026</title><style>
*{box-sizing:border-box}body{margin:0;color:#172b3a;background:#f0f3f5;font:17px/1.7 system-ui,sans-serif}main{max-width:1100px;margin:40px auto;padding:60px 65px;background:white}h1{font-size:36px;line-height:1.2;letter-spacing:-1px}h2{margin-top:54px;font-size:25px;line-height:1.3;border-top:1px solid #d9e0e5;padding-top:25px}p{margin:18px 0}a{color:#11627e;text-underline-offset:3px}table{border-collapse:collapse;width:100%;font-size:14px;line-height:1.5;margin:28px 0;display:block;overflow:auto}th{background:#eaf0f4;text-align:left}td,th{padding:12px;border-bottom:1px solid #dfe5e9;vertical-align:top}img{width:100%;height:auto}code{font-size:.85em;overflow-wrap:anywhere}li{margin:9px 0}strong{color:#0e3e50}@media(max-width:700px){main{margin:0;padding:25px}h1{font-size:29px}}@media print{body{background:white;font-size:11pt}main{margin:0;padding:0;max-width:none}h2{break-after:avoid}tr,img{break-inside:avoid}a{color:inherit}table{display:table;font-size:9pt}}
</style></head><body><main>${html}</main></body></html>`);
console.log('Saved readable HTML report');
