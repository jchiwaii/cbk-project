from pathlib import Path
import json, csv
ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'data/processed'
A=json.loads((P/'analysis.json').read_text())
N=json.loads((ROOT/'research/current-affairs.json').read_text())
def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(str(v) for v in r)+' |' for r in rows])
def fmt(v,n=2):return f'{v:,.{n}f}'
manifest=json.loads((ROOT/'data/manifest.json').read_text())
def link(pattern,title):
    s=next(x for x in manifest if pattern in x['path']);return f'[{title}]({s["url"]})'
growth=A['gdp_h1'];f=A['fiscal_year_ends'];t=A['trade_ytd'];rem=A['remittances_sources_ytd']
report=f'''# Kenya economy: data analysis and current affairs

Research cut-off: **13 November 2026, Africa/Nairobi**. This is a research deliverable for the planned Next.js dashboard. Dashboard design, implementation and publication are deferred at your request.

## Main assessment

Kenya's available data show continued economic expansion alongside a renewed squeeze from inflation, imports and government financing. The shilling is comparatively stable, credit is expanding and several service sectors are growing. These improvements coexist with faster import growth, a widening fiscal deficit, large interest costs and almost unchanged aggregate diaspora remittances in 2026 to date.

The central question is whether output and credit growth can translate into stronger household purchasing power and productive investment while fiscal and external pressures rise. Aggregate GDP alone does not establish that households are better off. The most useful dashboard should therefore place growth beside living costs, interest burdens, trade financing and the quality of the underlying data.

The conclusions below distinguish **downloaded observations**, **our calculations**, **published forecasts**, and **interpretation**. No forecast has been inserted into an actual-data series. Data availability differs by topic; this is not a single synchronized November snapshot.

{table(['Indicator','Latest available observation','Meaning'],[
['Real GDP growth','4.6% in 2025; published 5.3% Q1 and 5.1% Q2 2026','Expansion continues; GDP levels and published growth do not fully reconcile'],
['Inflation','7.32% year-on-year, October 2026','Up 2.76 percentage points from October 2025'],
['KES per USD','129.86 monthly average, October 2026','0.48% above October 2025; a higher quote means a weaker shilling'],
['Merchandise trade deficit','KES 1.327 trillion, January–August 2026','29.25% wider than the same months of 2025'],
['Diaspora remittances','USD 4.199 billion, January–October 2026','0.32% below the same months of 2025'],
['Public debt','KES 13.097 trillion, June 2026','55.94% domestic; total debt series ends before the domestic-only series'],
['Interest / government revenue','33.91%, FY2025/26','Interest alone; excludes principal repayments'],
['Average lending rate','14.40%, September 2026','Down from 14.81% in January; still above policy rate'],
['Private-sector credit, standard survey','10.35% year-on-year, August 2026','Nominal stock growth; not necessarily growth in new lending']])}

Source: downloaded CBK statistics and calculations described below. The full provenance is in `data/manifest.json` and `data/processed/observations.csv`.

![Six charts showing growth, inflation, exchange rates, trade, remittance origins and the interest burden](charts/economic-overview.png)

## 1. Output: a recovery whose composition matters

The annual series shows growth of -0.3% in 2020, 7.6% in 2021, 4.9% in 2022, 5.7% in 2023, 4.7% in 2024 and 4.6% in 2025. The pandemic rebound was followed by slower expansion. Nominal GDP reached KES 17.578 trillion in 2025, 8.29% above 2024; nominal growth includes price changes and must not be described as real production growth.

The quarterly file publishes 5.3% growth for Q1 and 5.1% for Q2 2026. However, its market-price GDP levels imply 5.06% and 5.08%, and combined first-half growth of **5.07%**, whereas the World Bank's current release reports **5.2%**. This is a source-vintage inconsistency, not a reason to silently replace one figure. The dashboard should use the published quarterly rates for official-growth cards and mark level-derived contributions as provisional until the source is reconciled.

The [KNBS Q2 2026 release catalogue](https://repository.knbs.or.ke/entities/publication/4c047f9c-5148-4361-9e1d-270ecbba4ed4) independently confirms the published 5.1% Q2 growth rate. That cross-check supports the official rate but does not resolve the Q1 level discrepancy.

The following calculations use the constant-2016-price levels within the quarterly download, comparing the same two quarters. Contributions equal each sector's absolute real-output change divided by total GDP in H1 2025. They explain the **level-derived 5.07%**, not the official 5.2% first-half headline. Sector shares are real-price shares, not current-price industry shares.

![Provisional GDP sector contributions with source discrepancy explicitly noted](charts/sector-contributions.png)

{table(['Sector','H1 growth, %','Contribution, percentage points','H1 real GDP share, %'],[[k,fmt(growth[k]['growth_percent']),fmt(growth[k]['contribution_pp']),fmt(growth[k]['share_real_gdp_percent'])] for k in ['Agriculture','Real estate','Financial & Insurance','Public administration','Transport & Storage','Wholesale & Retail Trade','Construction','Manufacturing','Information & Communication','Accommodation & restaurant']])}

Agriculture remains a large contributor despite growing more slowly than tourism-related activity. Accommodation and restaurants have the fastest growth among these sectors, but their small starting size limits their contribution to the national total. Finance, real estate, agriculture and public administration contribute more in absolute terms. Manufacturing expands by only about 3.3% on the available levels; this is weaker than several services and construction.

Interpretation: the recovery is broad enough to avoid describing it as a single-sector story, but high growth in a small sector should not dominate the narrative. A sustained rise in manufacturing and other tradable production would matter for export capacity and employment. These datasets do not identify employment intensity, productivity or the distribution of income, so those effects cannot be inferred from sector GDP alone.

FISIM is a negative accounting adjustment, not a conventional industry; its change and taxes on products must be retained in the reconciliation. Seasonally adjusted GDP is a separate aggregate and must never be added to the industry components. Annual GDP levels span statistical rebasing vintages, so a long-run real-level CAGR is deliberately not reported.

Sources: {link('Annual_GDP','Annual GDP')}; {link('Quarterly_GDP','Quarterly GDP and sector growth')}. KNBS compiles the national accounts distributed by CBK.

## 2. Inflation and household purchasing power

October's 12-month inflation rate was **7.32%**, compared with 4.56% in October 2025 and 4.40% in January 2026. The gap to the 7.5% upper edge of the policy target is only **0.18 percentage points**. The separately published annual-average inflation measure is 5.67%; it is not the current year-on-year rate.

The upward move is economically meaningful even while the headline remains inside the target range. Reuters' October release coverage reports food inflation at 10.2%, transport at 17.1% and housing/utilities at 3.7%. Those categories together account for 57% of CPI weight, but their inflation rates are not their percentage-point contributions. Household exposure varies by spending pattern, location and income.

Interpretation: people can experience worsening affordability while real GDP expands. Wages or cash income must rise sufficiently to offset their own consumption basket's cost increases. Earlier disinflation meant prices were rising more slowly; it did not reverse the accumulated increase in prices. This analysis does not compound overlapping year-on-year inflation rates to invent a cumulative price index. A consistent CPI index and household income series are needed for that extension.

Sources: [CBK inflation table](https://www.centralbank.go.ke/inflation-rates/); [Reuters, 30 October 2026](https://www.marketscreener.com/news/kenya-s-inflation-rises-to-highest-level-in-more-than-three-years-ce785fdbd881ff21).

## 3. Exchange rate, monetary conditions and credit

The monthly average USD quote fell from a peak of **159.69 KES/USD in January 2024** to **129.86 in October 2026**, an 18.68% decline in the quote. This is distinct from calculating the percentage appreciation of the reciprocal USD value of a shilling. October's quote is only 0.48% above a year earlier.

Exchange-rate stability reduces one source of uncertainty for importers and foreign-currency borrowers. It does not protect consumers from higher world fuel prices, freight costs or domestic taxes. It also does not prove the currency is overvalued or undervalued; that would require a consistent real effective exchange-rate framework and productivity/trade evidence.

CBK held its policy rate at 8.75% on 7 October. Average commercial-bank lending was 14.40% in September, against deposits at 6.94% and savings at 3.53%. The contemporaneous lending–deposit spread is **7.46 percentage points**. The policy decision and bank rates have different dates; their gap is descriptive, not a clean measure of monetary-policy transmission.

Standard-survey private-sector credit reached KES 4.304 trillion in August, growing 10.35% year-on-year. Standard M3 grew 11.23%. CPI-deflating the credit growth by August's 6.59% inflation gives an indicative real-stock increase of about **3.53%**: `(1.103489 / 1.0659 − 1) × 100`. This is an approximate purchasing-power adjustment, not a measure of business investment or loan disbursements.

The expanded survey, which includes additional institutions such as SACCOs and microfinance banks, reports KES 5.381 trillion of private-sector claims, up 10.04% from its own prior-year levels. The standard and expanded surveys must remain separate. The expanded sheet's reported M2/M3 growth rates also differ modestly from growth recomputed from its levels; the quality log preserves that distinction.

Interpretation: easier financial conditions and credit growth can support demand, but access still depends on collateral, borrower risk and bank appetite. The September CEO survey reports continuing access constraints despite lower rates. A positive credit-growth number does not establish that small firms or lower-income households can borrow affordably.

Sources: {link('Monthly_Exchange_rate_period_average','Monthly average exchange rates')}; [bank rates](https://www.centralbank.go.ke/commercial-banks-weighted-average-rates/); {link('377062609','standard monetary survey')}; {link('1715130057','expanded monetary survey')}; [October policy reporting](https://www.investing.com/news/economy-news/kenya-central-bank-keeps-main-lending-rate-unchanged-4937039).

## 4. Trade: import growth outpaces export growth

{table(['January–August, KES billion','2025','2026','Change, %'],[[k,fmt(t[k]['prior']/1000),fmt(t[k]['current']/1000),fmt(t[k]['growth_percent'])] for k in ['Imports CIF','Domestic exports FOB','Re-exports','Exports FOB','Trade balance']])}

The trade deficit increased by **KES 300.27 billion**. Exports covered **{fmt(t['Exports FOB']['current']/t['Imports CIF']['current']*100)}%** of imports, down from **{fmt(t['Exports FOB']['prior']/t['Imports CIF']['prior']*100)}%** a year earlier. The deficit row is negative; its positive percentage change denotes a larger deficit, not an improvement.

Domestic exports grew 14.13%, while re-exports grew just 0.57%. Re-exports represented **36.02%** of total exports in the 2026 period. The source explicitly notes a revision to include oil re-exports previously recorded as transit goods. Gross export receipts therefore should not be equated with Kenyan value added, and earlier unadjusted vintages should not be spliced into this series.

The largest contributions to the increased import bill came from fuels, chemicals and food. Together they account for about **76.9%** of its increase. Fuels alone represented **32.58%** of imports. Machinery and transport equipment grew too, which could support investment, but this broad category does not isolate productive capital goods from other purchases.

{table(['Import category','Jan–Aug 2026, KES bn','Growth, %','Increase, KES bn'],[[k,fmt(A['imports_commodity_ytd'][k]['current']/1000),fmt(A['imports_commodity_ytd'][k]['growth_percent']),fmt(A['imports_commodity_ytd'][k]['change']/1000)] for k in ['Mineral Fuels Lubricants and related Materials','Chemicals','Food  and Live Animals','Machinery and Transport Equipment']])}

For agricultural exports, value and volume tell different stories:

{table(['Export','Value growth, %','Volume growth, %','Weighted unit-value growth, %'],[[k,fmt(v['value_growth_percent']),fmt(v['volume_growth_percent']),fmt(v['unit_price_growth_percent'])] for k,v in A['principal_exports_ytd'].items()])}

Coffee combines higher volumes and higher unit values. Tea's higher earnings come despite a slight volume decline. Horticulture volumes grow faster than earnings, implying lower average unit values. Unit values reflect product mix as well as prices; they are not a pure export-price index. Period unit values are calculated as total value divided by total tonnes, never as a sum of monthly prices.

Regional trade is important: exports to African destinations total KES 640.30 billion, about 55.70% of overall exports. Uganda remains the largest named African destination at KES 324.56 billion, though down 9.06% from the same period in 2025. China accounts for about 23.88% of the 2026 import bill. Growth by trading partner uses each partner table's own prior-year values: the partner-import table's 2025 total differs from the trade-summary total, so the two growth decompositions cannot be combined without reconciliation. African import data stop in July, and their matched comparison uses January–July only.

Interpretation: import demand and fuel exposure are increasing the external financing requirement. A larger import bill is not automatically negative if it funds productive capacity, but composition, financing and future export earnings determine sustainability. The data here cannot distinguish how much of the bill reflects world prices, quantities or product-mix changes outside the three agricultural export series.

Sources: {link('Foreign_Trade_Summary','trade summary')}; {link('Imports_by_Commodities','import composition')}; {link('Principal_Exports','export volumes and values')}; {link('Exports_to_Selected_Africa','African destinations')}; {link('Imports_from_Selected_Rest','import origins')}.

## 5. Remittances: a substantial buffer with changing origins

Remittances reached **USD 5.037 billion in 2025**. Valuing each month's dollars at the corresponding average KES/USD rate produces approximately **KES 651.25 billion**, equivalent to **3.71% of 2025 nominal GDP**. This is an indicative conversion for scale, not the exchange rate actually received by every beneficiary.

The longer-run increase is substantial: historical annual inflows rose from USD 1.548 billion in 2015 to USD 5.037 billion in 2025, a compound annual increase of **12.52% in nominal dollars**. The near-flat 2026 year-to-date total therefore represents a marked slowdown relative to that decade-long trend. The comparison is descriptive; it does not assume the earlier growth rate was sustainable indefinitely.

January–October 2026 inflows were **USD 4.199 billion**, down **0.32%** year-on-year. October alone was USD 430.46 million, down 1.90% year-on-year. The aggregate stability hides major changes in source countries.

{table(['Source','Jan–Oct 2026, USD million','Growth, %','Change, USD million'],[[k,fmt(rem[k]['current']/1000),fmt(rem[k]['growth_percent']),fmt(rem[k]['change']/1000)] for k in ['America / U.S.A','Total Europe','Total Africa','Total Asia','Total Australia and Oceania','Asia / Saudia Arabia','Asia / United Arab Emirates']])}

US inflows fell by **USD 328.21 million** in the matched period. Higher inflows from Europe, Africa and Australia/Oceania offset much of the decline. Saudi-origin inflows were also sharply lower, while UAE-origin inflows rose. These shifts warrant investigation, but the source alone does not identify migration changes, transfer-routing changes, regulatory effects or household behavior as causes.

The US still provided **41.46%** of October inflows, leaving meaningful concentration risk. At the same time, growth elsewhere shows diversification. Regional totals and their constituent countries must not be added together; economic blocs such as EAC, COMESA and the EU overlap with geographic categories and are supplementary views.

Interpretation: remittances cushion household budgets and supply foreign exchange, but a nearly flat total offers little incremental financing for a rapidly widening import bill. Comparing remittances directly with the merchandise deficit can illustrate scale, but they are not interchangeable accounting entries: remittances form part of broader current transfers, while the current account also includes services and investment income.

Sources: {link('October2026.xlsx','CBK remittances by source workbook')}; [historical remittance table](https://www.centralbank.go.ke/diaspora-remittances/). Workbook totals reconcile to the web history within rounding over their overlapping periods.

## 6. Balance of payments: why the current account differs from trade

The 2025 BPM6 statement reports goods exports of KES 1.686 trillion and goods imports of KES 3.063 trillion, a goods deficit of KES 1.377 trillion. Net services contribute a surplus of **KES 323.90 billion**. Net primary income is **−KES 276.01 billion**, while net secondary income is **KES 956.08 billion**. The resulting current-account deficit is **KES 373.33 billion**, about **2.12% of calendar-year GDP**, compared with 1.76% in 2024.

Customs imports are CIF and customs exports FOB, whereas BPM6 uses its own coverage and adjustments, including FOB goods imports. These explain why customs and balance-of-payments figures should be displayed as separate measures rather than forced to match. Secondary income is broader than diaspora remittances and must not be labelled remittances.

The financial account records direct-investment liabilities of KES 143.63 billion and portfolio-investment liabilities of KES 238.77 billion. Net errors and omissions are KES 140.26 billion, a material statistical residual. This limits overconfident attribution of how every external financing flow was funded. Reserve-asset entries in this statement are transactions during the year, not the stock of foreign-exchange reserves.

The World Bank's November release reports reserves around USD 14.7 billion, equivalent to 5.9 months of imports. That is useful current context, but it is not a downloaded, validated reserve-stock time series in this package. CBK's reported 2026 current-account projection of 3.2% of GDP remains a forecast.

Source: {link('Balance_of_Payments','annual BPM6 statement')}; [World Bank update](https://www.worldbank.org/en/news/press-release/2026/11/04/kenya-s-economy-is-resilient-but-stronger-governance-could-unlock-gains-in-economi).

## 7. Government finances: interest and spending constrain room to act

The revenue/expenditure source is cumulative within the July–June fiscal year. The analysis uses June to compare complete fiscal years; adding its monthly observations would grossly overstate annual amounts. Expenditure is labelled commitment basis, which is not identical to cash payments or borrowing.

{table(['Fiscal year ending June','Revenue, KES bn','Expenditure, KES bn','Deficit incl. grants, KES bn','Interest / revenue, %'],[[p[:4],fmt(v['Total revenue']/1000),fmt(v['Total expenditure']/1000),fmt(v['Deficit including grants']/1000),fmt(v['Interest to revenue percent'])] for p,v in f.items()])}

In FY2025/26, revenue grew **7.15%**, expenditure **12.69%**, and the derived deficit including grants **31.16%**, to **KES 1.282 trillion**. Interest reached **KES 1.074 trillion**, absorbing **33.91% of total revenue**. Interest plus wages and pensions together absorbed about **60.2%** of revenue, before other recurrent services and development spending.

Development expenditure increased 25.85% to KES 725.85 billion, or 16.23% of total expenditure. This can support future capacity if projects are effective, but spending allocations are not evidence of project returns. The implied primary balance moved from a KES 17.49 billion surplus in FY2024/25 to a KES 207.89 billion deficit in FY2025/26. Definitions follow this table's reported revenue, grants and commitment expenditure; they are not a substitute for an official cash-basis primary-balance series.

The public-debt table reports **KES 13.097 trillion in June 2026**, with 55.94% domestic and 44.06% external. A newer domestic-instrument table reaches **KES 7.676 trillion in August**. Its bills and bonds indicate funding composition but not a complete maturity schedule. External debt for August is not present in the downloaded total-debt table, so August domestic debt is not combined with stale external debt to fabricate a current total.

A smaller fiscal inconsistency affects the prior-year baseline: FY2024/25 programme plus project grants exceed the reported total-grants field by KES 0.956 billion. The baseline consistently uses the reported total. Using the component sum would lower that year's deficit by KES 0.956 billion and increase its implied primary surplus by the same amount; it does not reverse the conclusion that FY2025/26 fiscal pressure increased.

Interpretation: the fiscal pressure is visible directly in interest-to-revenue and expenditure growth, without needing an imprecise debt/GDP ratio. Calendar GDP and fiscal-year flows cannot be mixed casually. Debt ratios reported elsewhere also differ by reference date, GDP vintage, guarantees and valuation. A weaker shilling can increase the KES value of existing external debt without a corresponding new loan; changes in the debt stock therefore do not equal the fiscal deficit.

The interest burden excludes principal repayment, so it is not total debt service. A full refinancing assessment still requires debt-service schedules, maturity profiles, currency composition and contingent liabilities. The downloaded files support a strong fiscal-pressure assessment, not a complete sovereign debt-sustainability model.

The decade-long comparison reinforces the fiscal finding. Between June 2015 and June 2025, nominal public debt grew at **15.30% annually**, while full-fiscal-year revenue grew at **10.56% annually**. Debt rose from **2.63 times annual revenue** in June 2015 to **3.99 times** in June 2025 and **4.13 times** in June 2026. Interest/revenue rose from **15.60%** in FY2014/15 to **33.91%** in FY2025/26. Debt/revenue is a scale comparison between a stock and an annual flow; it is not a repayment schedule or an estimate of years until debt is repaid. Both compound growth rates are nominal KES measures and reflect valuation, coverage and economic changes as well as borrowing and revenue policy.

Sources: {link('Revenue_and_Expenditure','revenue and expenditure')}; {link('Public_Debt','public debt')}; {link('681695542','newer domestic debt instruments')}. Both instrument vintages are retained, with differences logged.

## 8. What institutions, businesses and citizens are saying

This is a selected, attributable evidence review rather than a social-media sentiment score. Survey fieldwork dates, publication dates and forecast horizons differ.

'''
for item in N['items']:
    report+=f"**{item['publisher']} — {item['date']} ({item['type']}).** {item['summary']} {item['caveat']} [Source]({item['url']}).\n\n"
report+='''The common thread is a gap between improving aggregate activity and persistent cost pressures. CEO optimism and a PMI above 50 can coexist with households struggling to afford essentials. The historical citizen survey provides context, but it cannot establish today's national mood. Public comments on news stories are not a representative sample, and no claim about “what all Kenyans think” is made.

## 9. Risks, transmission channels and what to monitor

| Scenario or pressure | Transmission channel | Indicators to watch | Interpretation limit |
| --- | --- | --- | --- |
| Higher fuel prices or shipping disruption | Import bill, transport costs, inflation and possibly subsidy spending rise | Fuel imports, transport CPI, freight costs, exchange rate | Current data do not isolate global price from volume effects |
| Weaker remittances | Less household support and foreign-currency supply | Total and US inflows, rolling 12-month total, regional offsets | Origin changes do not establish a migration-policy cause |
| Fiscal slippage | More borrowing, interest costs and possible pressure on private financing | Matched fiscal YTD revenue/spending, primary balance, yields | Credit crowding out is a hypothesis requiring further testing |
| Better business conditions | More orders, investment and productive credit | PMI, sector GDP, credit, machinery imports | Survey optimism is not realized investment |
| Weather disruption | Agricultural output and food prices respond in opposite directions | Agriculture GDP, food CPI, crop volumes, rainfall | No causal weather model is estimated here |
| Currency depreciation | Imported inputs and foreign-debt valuation rise | Monthly FX, foreign-currency credit, external debt | KES debt-stock changes mix valuation and borrowing |

No probabilities or point forecasts are assigned to these scenarios. A mechanical sensitivity illustrates exposure, not a prediction: a 10% drop in annual remittances relative to 2025 would remove roughly USD 504 million of inflows before offsets or behavioral changes. A 10% increase in the January–August fuel bill, holding quantities and everything else fixed, would add about KES 80.7 billion to imports. These shocks should not be mechanically translated into GDP or the exchange rate without a model.

## 10. Data quality and publication rules

The package preserves 20 linked CBK files, plus the downloaded HTML tables used for inflation, remittances history and bank rates. The processed observation table carries dataset, period, metric, numeric value, units, URL, original file, source locator and status. The coverage table records first/last periods and observations. A source manifest includes download timestamps and SHA-256 hashes.

Important findings:

1. **GDP levels versus rates:** the quarterly source does not fully reconcile; retain official rates and mark level-based decomposition provisional.
2. **Duplicate bank rates:** February 2026 has conflicting deposit and savings values; the conflicting metrics are excluded. Identical lending/overdraft duplicates are deduplicated.
3. **Trade vintages:** partner-import totals differ from headline customs totals in some historical months. Headline growth uses only the trade-summary vintage.
4. **Debt vintages:** two instrument files differ; the newer file is used for current instrument composition, and both originals remain available.
5. **Expanded money:** reported growth and growth calculated from some underlying levels differ; both should be explicitly labelled.
6. **End-period FX:** the downloaded file ends in an incomplete August 2011 row. It is retained as source evidence and excluded from current analysis.
7. **Different clocks:** annual, quarterly, monthly and fiscal-year data are not forced into a common “latest” period. Partial years always compare matching months.
8. **No false zeros:** blank numeric cells remain missing. The early remittances web table contains zero regional fields despite positive totals; these are not evidence that the regions sent nothing.
9. **Rebasing and revisions:** historical data are the current downloaded vintage, not a reconstruction of what was known at the time. Backtests would need historical release snapshots.
10. **Coverage gaps:** a full employment/income, poverty, county, productivity, debt-service and distributional assessment requires additional KNBS, Treasury and survey datasets. “Economy-wide” macro coverage does not mean every dimension of welfare is measured.

Annual nominal GDP units are interpreted as KES million from the CBK statistical context, since the annual CSV header itself omits unit/base metadata. Ratios using this series should carry that metadata caveat until checked against the corresponding KNBS Economic Survey. Formula-based checks verify internal consistency; they do not certify the underlying official source is error-free.

## 11. Dashboard content ready for your design

The proposed Next.js application can use the prepared CSV/JSON outputs without re-scraping CBK in the browser. Suggested views are Overview, Growth and sectors, Prices and households, Trade and external balance, Remittances, Government finances, Money and credit, and Evidence and methodology.

Each headline should show its observation period, unit, comparable prior period, source and any material quality flag. Charts should offer matched time ranges and keep annual/fiscal/quarterly measures separate. Download controls should expose both the original file and cleaned series. News cards need publication dates, attribution and a distinction between observations and forecasts. A narrative should link to the specific calculation supporting it.

Do not publish sector contributions as definitive until the GDP mismatch is resolved. Do not merge current-account and customs trade balances; do not sum regional remittances and their countries; do not sum cumulative fiscal observations; do not show partial-year totals against full years. Monthly rates use period observations or an explicitly defined average, stocks use end-period values, and flows use sums over complete matched periods.

The dashboard is intentionally not built or hosted yet. Your design will determine its layout and styling. The data and research can be reviewed independently now.

## Deliverables and reproducibility

- `data/raw/`: original CBK files, unchanged.
- `data/pages/`: downloaded CBK page snapshots.
- `data/manifest.json`: file-level URLs, timestamps and hashes.
- `data/processed/observations.csv`: normalized observations with provenance.
- `data/processed/analysis.json`: computed analysis results.
- `data/processed/dashboard-data.json`: summary payload for later Next.js integration.
- `data/processed/coverage.csv` and `quality_issues.json`: availability and validation findings.
- `data/processed/*comparison.csv`: matched-period analysis tables.
- `research/current-affairs.json`: dated commentary evidence and limitations.

Collection and calculation scripts are included. Refreshing should first archive the previous snapshot; CBK may revise values or change links. The present files are a fixed research snapshot, not an automated real-time feed.
'''
(ROOT/'research/kenya-economy-analysis.md').write_text(report)
catalog=['# Source file inventory','',table(['Dataset/file','Format','Original URL'],[[x['title'],Path(x['path']).suffix,f"[Download]({x['url']})"] for x in manifest])]
(ROOT/'research/source-catalog.md').write_text('\n'.join(catalog))
print('Wrote report:',len(report.split()),'words')
