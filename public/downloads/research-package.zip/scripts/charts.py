"""Static research figures; deliberately separate from the planned dashboard."""
import os,csv,json,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.mplconfig'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
P=ROOT/'data/processed';OUT=ROOT/'research/charts';OUT.mkdir(exist_ok=True)
A=json.loads((P/'analysis.json').read_text())
def read(name):return list(csv.DictReader((P/(name+'.csv')).open()))
def monthly(name,metric,start='2019-01'):
    rows=[r for r in read(name) if r['period']>=start and r.get(metric)]
    return [datetime.date.fromisoformat(r['period']+'-01') for r in rows],[float(r[metric]) for r in rows]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','axes.titlesize':12,'axes.labelcolor':'#344054','text.color':'#152536','axes.edgecolor':'#ccd3da','grid.color':'#e7eaed','figure.facecolor':'white'})
blue='#176b87';orange='#d27a32';red='#aa4150'
fig,axs=plt.subplots(3,2,figsize=(15,13),layout='constrained')
fig.suptitle('Kenya economic evidence | 13 November 2026\nDifferent indicators have different reporting dates',fontsize=19,fontweight='bold')
fig.supxlabel('Source: Central Bank of Kenya downloads and author calculations. Definitions and source caveats in the accompanying report.',fontsize=10,color='#526273')
ax=axs[0,0];r=[r for r in read('annual_gdp') if int(r['period'])>=2015]
ax.bar([int(x['period']) for x in r],[float(x['Reported real GDP growth']) for x in r],color=blue)
ax.axhline(0,color='#697586',lw=.7);ax.set(title='Annual real GDP growth',ylabel='Percent');ax.set_xticks([2015,2017,2019,2021,2023,2025])
ax=axs[0,1];x,y=monthly('inflation','12-month inflation','2020-01');ax.axhspan(2.5,7.5,color='#e5f0e8',label='Target range');ax.plot(x,y,color=red,lw=2);ax.set(title='Inflation is near the upper target limit',ylabel='Year-on-year percent');ax.legend(frameon=False,loc='upper right');ax.annotate('7.32%',(x[-1],y[-1]),xytext=(-45,13),textcoords='offset points',color=red,fontweight='bold')
ax=axs[1,0];x,y=monthly('fx_average','USD','2020-01');ax.plot(x,y,color=blue,lw=2);ax.set(title='Shilling recovered from the 2024 trough',ylabel='KES per USD, monthly average');ax.annotate('129.86',(x[-1],y[-1]),xytext=(-48,13),textcoords='offset points',color=blue,fontweight='bold')
ax=axs[1,1];labels=['2025 Jan–Aug','2026 Jan–Aug'];t=A['trade_ytd']
ax.bar([-.18,.82],[t['Exports FOB'][k]/1e6 for k in ['prior','current']],width=.36,label='Exports FOB',color=blue)
ax.bar([.18,1.18],[t['Imports CIF'][k]/1e6 for k in ['prior','current']],width=.36,label='Imports CIF',color=orange);ax.set_xticks([0,1],labels);ax.set(title='Import growth exceeds export growth',ylabel='KES trillion');ax.legend(frameon=False)
ax=axs[2,0];r=A['remittances_sources_ytd'];labels=['America','Europe','Asia','Africa','Australia / Oceania'];keys=['Total America','Total Europe','Total Asia','Total Africa','Total Australia and Oceania'];delta=[r[k]['change']/1000 for k in keys]
ax.barh(labels,delta,color=[red if v<0 else blue for v in delta]);ax.axvline(0,color='#697586',lw=.7);ax.set(title='Remittance origins are shifting',xlabel='Jan–Oct 2026 vs 2025 change, USD million');ax.invert_yaxis()
ax=axs[2,1];f=A['fiscal_year_ends'];years=[int(k[:4]) for k in f];vals=[v['Interest to revenue percent'] for v in f.values()];ax.bar(years,vals,color=orange);ax.set(title='Interest absorbs one-third of revenue',ylabel='Percent of revenue',xlabel='Fiscal year ending June');ax.set_ylim(0,40);ax.set_xticks(years)
for ax in axs.flat:ax.grid(axis='y',alpha=.6);ax.set_axisbelow(True)
for ax in [axs[0,1],axs[1,0]]:ax.xaxis.set_major_locator(mdates.YearLocator(2));ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
fig.savefig(OUT/'economic-overview.png',dpi=160,bbox_inches='tight');fig.savefig(OUT/'economic-overview.svg',bbox_inches='tight');plt.close(fig)
g=A['gdp_h1'];names=['Agriculture','Financial & Insurance','Real estate','Public administration','Transport & Storage','Wholesale & Retail Trade','Construction','Education','Manufacturing','Information & Communication','Accommodation & restaurant']
fig,ax=plt.subplots(figsize=(10,6),layout='constrained');ax.barh(names,[g[k]['contribution_pp'] for k in names],color=blue);ax.invert_yaxis();ax.set(title='Provisional sector contributions to H1 2026 growth',xlabel='Percentage points, calculated from constant-price levels');ax.grid(axis='x',alpha=.6);ax.set_axisbelow(True)
fig.suptitle('Levels imply 5.07% total growth; published first-half headline is 5.2%.\nContributions require source-vintage reconciliation.',fontsize=11,color=red)
fig.supxlabel('Source: CBK quarterly GDP file. Selected sectors shown; these bars are not the complete GDP reconciliation.',fontsize=9,color='#526273')
fig.savefig(OUT/'sector-contributions.png',dpi=160,bbox_inches='tight');plt.close(fig)
print('Saved research charts')
