# Source file inventory

| Dataset/file | Format | Original URL |
| --- | --- | --- |
| Quarterly GDP | .csv | [Download](https://www.centralbank.go.ke/uploads/national_accounts_statistics/731217938_Quarterly GDP.csv) |
| Annual GDP | .csv | [Download](https://www.centralbank.go.ke/uploads/national_accounts_statistics/1364443532_Annual GDP.csv) |
| Domestic Debt by Instrument | .csv | [Download](https://www.centralbank.go.ke/uploads/government_finance_statistics/681695542_Domestic Debt by Instrument.csv) |
| Public Debt | .csv | [Download](https://www.centralbank.go.ke/uploads/government_finance_statistics/1071243323_Public Debt.csv) |
| Revenue and Expenditure | .csv | [Download](https://www.centralbank.go.ke/uploads/government_finance_statistics/838648518_Revenue and Expenditure.csv) |
| Domestic Debt By Instrument | .csv | [Download](https://www.centralbank.go.ke/uploads/government_finance_statistics/502403123_Domestic Debt by Instrument.csv) |
| Remittances by Source (‘000 USD Equivalent) | .xlsx | [Download](https://www.centralbank.go.ke/wp-content/uploads/2026/11/October2026.xlsx) |
| Value of Selected Domestic Exports | .csv | [Download](https://www.centralbank.go.ke/uploads/balance_of_payment_statistics/748421847_Value of Selected Domestic Exports - Selected Comms.csv) |
| Value of Exports to Selected Rest of World countries | .csv | [Download](https://www.centralbank.go.ke/uploads/balance_of_payment_statistics/369664362_Value of Exports to Selected Rest of World Countries.csv) |
| Value of Exports to selected African Countries | .csv | [Download](https://www.centralbank.go.ke/uploads/balance_of_payment_statistics/1702776071_Value of Exports to Selected Africa Countries.csv) |
| Value of Direct Imports by Commodities | .csv | [Download](https://www.centralbank.go.ke/uploads/balance_of_payment_statistics/781277840_Value of Direct Imports by Commodities.csv) |
| Value of Direct Imports from Selected Rest of World | .csv | [Download](https://www.centralbank.go.ke/uploads/balance_of_payment_statistics/1977377807_Value of Direct Imports from Selected Rest of the World Countries.csv) |
| Principal Exports, Volume, Value and Unit prices | .csv | [Download](https://www.centralbank.go.ke/uploads/balance_of_payment_statistics/2129394624_Principal Exports_Volume, Value and Unit Prices.csv) |
| Foreign Trade Summary | .csv | [Download](https://www.centralbank.go.ke/uploads/balance_of_payment_statistics/2019178257_Foreign Trade Summary.csv) |
| Value of Direct Imports from selected African Countries | .csv | [Download](https://www.centralbank.go.ke/uploads/balance_of_payment_statistics/1064070543_Value of Direct Imports from Selected African Countries.csv) |
| BOP Annual | .csv | [Download](https://www.centralbank.go.ke/uploads/balance_of_payment_statistics/1657248905_Balance of Payments Statement (Annual Calender Year).csv) |
| Monetary & Finance Statistics | .csv | [Download](https://www.centralbank.go.ke/uploads/monetary_and_finance_statistics/377062609_Depository Corporation Survey - CSV.csv) |
| Monetary & Finance Statistics (Expanded) | .csv | [Download](https://www.centralbank.go.ke/uploads/monetary_and_finance_statistics/1715130057_Depository Corporation Survey_Expanded- CSV.csv) |
| Exchange Rates Average Period | .csv | [Download](https://www.centralbank.go.ke/uploads/exchange_rates/102769479_Monthly Exchange rate (period average).csv) |
| Exchange Rates End Period | .csv | [Download](https://www.centralbank.go.ke/uploads/exchange_rates/1091858998_Monthly exchange rate (end period).csv) |