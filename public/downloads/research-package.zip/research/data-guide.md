# Dataset coverage and calculation guide

Snapshot date: 13 November 2026. Period ranges describe available observations, not a promise of complete coverage for every metric.

| Dataset | First period | Last period | Periods | Numeric observations |
|---|---|---|---:|---:|
| annual_gdp | 2000 | 2025 | 26 | 78 |
| bank_rates | 2026-01 | 2026-09 | 9 | 34 |
| bop | 2019 | 2025 | 7 | 357 |
| debt_instruments_502403123 | 1999-09 | 2026-06 | 316 | 2,212 |
| debt_instruments_681695542 | 1999-09 | 2026-08 | 318 | 2,226 |
| exports_africa | 1998-01 | 2026-08 | 344 | 4,127 |
| exports_commodity | 1998-08 | 2026-08 | 337 | 3,032 |
| exports_world | 1998-01 | 2026-08 | 344 | 4,127 |
| fiscal | 1999-09 | 2026-07 | 317 | 5,955 |
| fx_average | 1993-01 | 2026-10 | 406 | 8,085 |
| imports_africa | 1998-01 | 2026-07 | 343 | 2,742 |
| imports_commodity | 1998-08 | 2026-08 | 337 | 3,370 |
| imports_world | 1998-01 | 2026-08 | 344 | 4,436 |
| inflation | 2005-01 | 2026-10 | 262 | 524 |
| money_expanded | 2014-01 | 2026-08 | 152 | 12,000 |
| money_standard | 1997-12 | 2026-08 | 345 | 8,970 |
| principal_exports | 1998-08 | 2026-08 | 337 | 3,033 |
| public_debt | 1999-09 | 2026-06 | 316 | 948 |
| quarterly_gdp | 2009-Q1 | 2026-Q2 | 70 | 1,470 |
| quarterly_gdp_growth | 2010-Q1 | 2026-Q2 | 66 | 1,320 |
| remittances_history | 2004-01 | 2026-10 | 274 | 1,096 |
| remittances_sources | 2019-02 | 2026-10 | 93 | 4,557 |
| trade | 1998-08 | 2026-08 | 337 | 2,359 |

## Definitions

- Year-on-year change: `(value at t / value at t−12 months − 1) × 100`; quarterly comparisons use the same quarter a year earlier.
- YTD growth: sum matching January-to-cutoff months in both years, then compute percentage change.
- Stocks: retain period-end amounts. Never add monthly debt or money stocks.
- Fiscal deficit including grants: commitment-basis expenditure minus revenue minus reported grants. Positive derived values mean a deficit.
- Primary deficit: deficit including grants minus domestic and foreign interest. A negative result is a primary surplus.
- Interest burden: domestic plus foreign interest divided by total revenue, excluding grants.
- Trade balance: FOB exports minus CIF imports in the customs table. Negative means deficit.
- Export coverage: FOB exports / CIF imports × 100.
- Agricultural unit value: summed KES-million export value × 1,000,000 / summed tonnes.
- GDP contribution: sector constant-price level change / previous matching-period aggregate GDP × 100. Provisional because the source levels disagree with the Q1 published growth rate.
- Remittance GDP share: sum monthly USD-thousand remittances × monthly KES/USD / 1,000, then divide KES-million nominal annual GDP. The currency conversion is indicative.
- Current account GDP share: annual BPM6 current account divided by matching calendar-year nominal GDP.
- Growth across a sign change is not economically intuitive. Present primary fiscal balance changes in KES instead of percentage growth.

## Source identifiers

`observations.csv` retains source locators. CSV rows/columns are one-based. The XLSX source uses A1 cell references. HTML row locators count source table rows, including header rows. Blank/conflicting values are not interpolated. Source numerical values retain more precision than report displays.

## Selected exclusions

The incomplete end-period exchange-rate file is retained raw but not analyzed. February 2026 bank deposit/savings conflicts are excluded. Historical annual real-GDP levels are not linked across rebasing vintages. Economic-bloc remittance rows are never summed into regional totals.